import urllib
import json
import requests

def printRes(data)
 theJSON=json.loads(data)
 print(json.dumps(theJSON)) 

    $(".track").on("click", function(){
       
       var matchvalue = $('.textbox').val();
          $.ajax({ 
            url: 'http://localhost:8080/parse',
            data: { trackId: matchvalue },
            type: 'post',
            dataType: 'json'
        }).done(function(responseData) {
            
            $('.tbl').empty();
            for (var i = 0; i < responseData.length; i++) {
                $('.tbl').append("<tr><td>"+ responseData[i].trackid +"</td><td>"+ responseData[i].ship_date +"</td><td>"+ responseData[i].status +"</td><td>"+ responseData[i].delivery +"</td><td>");
            }
        }).fail(function() {
            console.log('Failed');
        });
});

if __name__=="__main__":
	main()
 
 